from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "student_records.db"

app = Flask(__name__)
app.secret_key = "change-this-demo-secret-key"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def calculate_hash(index, timestamp, data_json, previous_hash):
    payload = {
        "index": index,
        "timestamp": timestamp,
        "data": json.loads(data_json),
        "previous_hash": previous_hash,
    }
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def init_db():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            college TEXT NOT NULL,
            course TEXT NOT NULL,
            grade TEXT NOT NULL,
            created_at TEXT NOT NULL,
            block_index INTEGER
        );

        CREATE TABLE IF NOT EXISTS blocks (
            block_index INTEGER PRIMARY KEY,
            timestamp TEXT NOT NULL,
            data_json TEXT NOT NULL,
            previous_hash TEXT NOT NULL,
            block_hash TEXT NOT NULL
        );
        """)
        exists = conn.execute(
            "SELECT block_index FROM blocks WHERE block_index = 0"
        ).fetchone()
        if not exists:
            timestamp = datetime.now(timezone.utc).isoformat()
            data_json = canonical_json({"message": "Genesis Block"})
            previous_hash = "0"
            block_hash = calculate_hash(0, timestamp, data_json, previous_hash)
            conn.execute(
                """INSERT INTO blocks
                   (block_index, timestamp, data_json, previous_hash, block_hash)
                   VALUES (?, ?, ?, ?, ?)""",
                (0, timestamp, data_json, previous_hash, block_hash),
            )


def add_student_record(student):
    with get_db() as conn:
        # Prevent duplicate IDs before creating a block.
        if conn.execute(
            "SELECT 1 FROM students WHERE student_id = ?", (student["student_id"],)
        ).fetchone():
            raise ValueError("That Student ID already exists.")

        last = conn.execute(
            "SELECT block_index, block_hash FROM blocks ORDER BY block_index DESC LIMIT 1"
        ).fetchone()
        index = last["block_index"] + 1
        previous_hash = last["block_hash"]
        timestamp = datetime.now(timezone.utc).isoformat()
        data_json = canonical_json(student)
        block_hash = calculate_hash(index, timestamp, data_json, previous_hash)

        conn.execute(
            """INSERT INTO students
               (student_id, full_name, college, course, grade, created_at, block_index)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (student["student_id"], student["full_name"], student["college"],
             student["course"], student["grade"], timestamp, index),
        )
        conn.execute(
            """INSERT INTO blocks
               (block_index, timestamp, data_json, previous_hash, block_hash)
               VALUES (?, ?, ?, ?, ?)""",
            (index, timestamp, data_json, previous_hash, block_hash),
        )


def verify_chain():
    with get_db() as conn:
        blocks = conn.execute(
            "SELECT * FROM blocks ORDER BY block_index ASC"
        ).fetchall()
        if not blocks:
            return False, "No blocks found."

        expected_previous_hash = "0"
        expected_index = 0

        for block in blocks:
            if block["block_index"] != expected_index:
                return False, f"Block sequence error at block {block['block_index']}."
            if block["previous_hash"] != expected_previous_hash:
                return False, f"Previous-hash link is invalid at block {block['block_index']}."

            calculated = calculate_hash(
                block["block_index"], block["timestamp"],
                block["data_json"], block["previous_hash"]
            )
            if calculated != block["block_hash"]:
                return False, f"Block data/hash mismatch at block {block['block_index']}."

            if block["block_index"] > 0:
                data = json.loads(block["data_json"])
                row = conn.execute(
                    "SELECT * FROM students WHERE student_id = ?",
                    (data.get("student_id", ""),)
                ).fetchone()
                if not row:
                    return False, f"Student record missing for block {block['block_index']}."
                current_record = {
                    "student_id": row["student_id"],
                    "full_name": row["full_name"],
                    "college": row["college"],
                    "course": row["course"],
                    "grade": row["grade"],
                }
                if current_record != data:
                    return False, f"Student database record differs from block {block['block_index']}."

            expected_previous_hash = block["block_hash"]
            expected_index += 1

        return True, f"All {len(blocks)} blocks and student records passed integrity checks."


@app.route("/")
def index():
    with get_db() as conn:
        count = conn.execute("SELECT COUNT(*) AS n FROM students").fetchone()["n"]
        block_count = conn.execute("SELECT COUNT(*) AS n FROM blocks").fetchone()["n"]
        recent = conn.execute(
            "SELECT student_id, full_name, course, grade, created_at FROM students ORDER BY id DESC LIMIT 5"
        ).fetchall()
    ok, message = verify_chain()
    return render_template("index.html", count=count, block_count=block_count,
                           recent=recent, chain_ok=ok, chain_message=message)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        student = {
            "student_id": request.form.get("student_id", "").strip(),
            "full_name": request.form.get("full_name", "").strip(),
            "college": request.form.get("college", "").strip(),
            "course": request.form.get("course", "").strip(),
            "grade": request.form.get("grade", "").strip(),
        }
        if not all(student.values()):
            flash("Please fill in every field.", "error")
            return render_template("register.html", form=student)
        if len(student["student_id"]) > 40 or len(student["full_name"]) > 100:
            flash("Student ID or name is too long.", "error")
            return render_template("register.html", form=student)
        try:
            add_student_record(student)
            flash("Student registered and blockchain block created successfully.", "success")
            return redirect(url_for("records"))
        except ValueError as exc:
            flash(str(exc), "error")
        except sqlite3.Error:
            flash("Database error. Please try again.", "error")
        return render_template("register.html", form=student)
    return render_template("register.html", form={})


@app.route("/records")
def records():
    query = request.args.get("q", "").strip()
    with get_db() as conn:
        if query:
            like = f"%{query}%"
            rows = conn.execute(
                """SELECT student_id, full_name, college, course, grade, created_at, block_index
                   FROM students WHERE student_id LIKE ? OR full_name LIKE ? OR course LIKE ?
                   ORDER BY id DESC""", (like, like, like)
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT student_id, full_name, college, course, grade, created_at, block_index
                   FROM students ORDER BY id DESC"""
            ).fetchall()
    return render_template("records.html", records=rows, query=query)


@app.route("/verify", methods=["GET", "POST"])
def verify():
    result = None
    student_id = ""
    if request.method == "POST":
        student_id = request.form.get("student_id", "").strip()
        with get_db() as conn:
            row = conn.execute(
                "SELECT * FROM students WHERE student_id = ?", (student_id,)
            ).fetchone()
            if row:
                block = conn.execute(
                    "SELECT * FROM blocks WHERE block_index = ?", (row["block_index"],)
                ).fetchone()
                chain_ok, chain_message = verify_chain()
                record_data = {
                    "student_id": row["student_id"],
                    "full_name": row["full_name"],
                    "college": row["college"],
                    "course": row["course"],
                    "grade": row["grade"],
                }
                block_matches = bool(block) and json.loads(block["data_json"]) == record_data
                result = {
                    "found": True,
                    "valid": bool(block_matches and chain_ok),
                    "student": row,
                    "message": "Record is authentic and blockchain integrity is valid."
                               if block_matches and chain_ok
                               else "Verification failed: record or blockchain integrity check failed.",
                    "chain_message": chain_message,
                }
            else:
                result = {"found": False, "valid": False,
                          "message": "No record found for that Student ID."}
    return render_template("verify.html", result=result, student_id=student_id)


@app.route("/blockchain")
def blockchain():
    with get_db() as conn:
        blocks = conn.execute(
            "SELECT * FROM blocks ORDER BY block_index ASC"
        ).fetchall()
    ok, message = verify_chain()
    return render_template("blockchain.html", blocks=blocks, chain_ok=ok,
                           chain_message=message)


@app.route("/integrity")
def integrity():
    ok, message = verify_chain()
    return render_template("integrity.html", chain_ok=ok, chain_message=message)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
