# Blockchain-Based Student Identity and Record Verification System

A local educational project using Python, Flask, SQLite, and SHA-256.

## Features
- Register student identity and academic details.
- Save records persistently in SQLite.
- Create a linked blockchain block for every new student record.
- Search student records.
- Verify a student record against its block and verify the whole chain.
- Browse blocks, hashes, timestamps, and previous-hash links.
- Responsive HTML/CSS interface.

## Requirements
- Python 3.10 or newer recommended
- Flask

## Setup (Windows)
1. Extract the ZIP file.
2. Open the extracted `student_blockchain_project` folder in VS Code.
3. Open a terminal in that folder.
4. (Optional but recommended) Create a virtual environment:
   `python -m venv .venv`
5. Activate it:
   PowerShell: `.venv\Scripts\Activate.ps1`
   Command Prompt: `.venv\Scripts\activate.bat`
6. Install dependency:
   `pip install -r requirements.txt`
7. Start the website:
   `python app.py`
8. Open the local address shown in the terminal, usually `http://127.0.0.1:5000`.

## First use
- Select **Register** and add a sample student.
- Open **Records** to see saved records.
- Open **Verify** and enter that Student ID.
- Open **Blockchain** to inspect the blocks and hashes.
- Use **Integrity status** on the dashboard to check the chain.

## Database
`student_records.db` is included and initialized with a genesis block. The app also creates the tables if they do not exist. Back up this file to preserve records.

## Important limitations
This is a classroom prototype, not a production identity service. It is a single-server, local SQLite ledger, not a distributed blockchain network. It has no user authentication, university digital signatures, role-based permissions, or secure certificate issuance. Do not enter real sensitive student information. For deployment, add authentication, CSRF protection, authorization, backups, audit logging, HTTPS, data-retention rules, and a real permissioned blockchain or independently controlled ledger nodes. The Flask secret key should be changed before any deployment.

The integrity checker detects altered records/blocks in this prototype, but an administrator with direct access to the SQLite database could rewrite the entire chain. A production system needs independent consensus or externally anchored hashes to resist that threat.
